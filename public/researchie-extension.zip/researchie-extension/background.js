// Researchie Chrome Extension Background Service Worker
importScripts('auth.js'); // adds the saved token to requests to the connected server

const CANDIDATE_ORIGINS = [
  'http://localhost:3001',
  'http://localhost:3000',
  'http://localhost:3002',
  'http://127.0.0.1:3001',
  'http://127.0.0.1:3000',
];

let cachedWorkingOrigin = null;

async function getWorkingApiBase() {
  // A saved server address (popup -> Connect) wins over looking for a local one.
  const saved = await chrome.storage.local.get(['serverUrl']);
  if (saved.serverUrl) return saved.serverUrl.replace(/\/+$/, '') + '/api';

  if (cachedWorkingOrigin) {
    try {
      const ping = await fetch(`${cachedWorkingOrigin}/api/projects`, { signal: AbortSignal.timeout(1200) });
      if (ping.ok) return `${cachedWorkingOrigin}/api`;
    } catch {}
  }

  for (const origin of CANDIDATE_ORIGINS) {
    try {
      const ping = await fetch(`${origin}/api/projects`, { signal: AbortSignal.timeout(1200) });
      if (ping.ok) {
        cachedWorkingOrigin = origin;
        await chrome.storage.local.set({ apiBaseUrl: `${origin}/api`, apiOrigin: origin });
        return `${origin}/api`;
      }
    } catch {}
  }

  const storage = await chrome.storage.local.get(['apiBaseUrl']);
  return storage.apiBaseUrl || 'http://localhost:3001/api';
}

chrome.runtime.onInstalled.addListener(async () => {
  chrome.contextMenus.create({
    id: 'researchie-save-selection',
    title: 'Save selection to Researchie (Alt+S)',
    contexts: ['selection'],
  });

  chrome.contextMenus.create({
    id: 'researchie-pick-block',
    title: 'Inspect & save DOM block (Alt+B)',
    contexts: ['page'],
  });

  chrome.contextMenus.create({
    id: 'researchie-crop-image',
    title: 'Crop screen region (Alt+C)',
    contexts: ['page'],
  });

  chrome.contextMenus.create({
    id: 'researchie-save-page',
    title: 'Save page link to Researchie',
    contexts: ['page', 'link'],
  });

  if (chrome.sidePanel && typeof chrome.sidePanel.setPanelBehavior === 'function') {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {});
  }

  // Sync projects from active backend only if activeProjectId is not set
  try {
    const storage = await chrome.storage.local.get(['activeProjectId']);
    const apiBase = await getWorkingApiBase();
    const res = await fetch(`${apiBase}/projects`);
    if (res.ok) {
      const json = await res.json();
      if (json.data && json.data.length > 0) {
        if (!storage.activeProjectId) {
          const first = json.data[0];
          await chrome.storage.local.set({
            activeProjectId: first.id,
            activeProjectTitle: first.title,
            activeProjectDesc: first.description || '',
            activeProjectColor: first.color_badge || first.color || '#325FEC',
            extensionEnabled: true,
          });
          return;
        } else {
          const match = json.data.find((p) => p.id === storage.activeProjectId);
          if (match) {
            await chrome.storage.local.set({
              activeProjectTitle: match.title,
              activeProjectDesc: match.description || '',
              activeProjectColor: match.color_badge || match.color || '#325FEC',
            });
            return;
          }
        }
      }
    }
  } catch {}

  chrome.storage.local.get(['activeProjectId', 'extensionEnabled'], (result) => {
    if (!result.activeProjectId) {
      chrome.storage.local.set({
        activeProjectId: 'proj-ai-main',
        activeProjectTitle: 'Artificial Intelligence & RAG',
        activeProjectDesc: 'Core research umbrella covering vector retrieval architectures, multimodal synthesis, and knowledge graph augmentation.',
        activeProjectColor: '#325FEC',
        extensionEnabled: true,
      });
    }
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || !tab.id) return;

  if (info.menuItemId === 'researchie-save-selection' && info.selectionText) {
    chrome.tabs.sendMessage(tab.id, {
      action: 'SAVE_SELECTION_TRIGGERED',
      selectionText: info.selectionText,
    });
  } else if (info.menuItemId === 'researchie-pick-block') {
    chrome.tabs.sendMessage(tab.id, { action: 'TRIGGER_BLOCK_PICKER' });
  } else if (info.menuItemId === 'researchie-crop-image') {
    chrome.tabs.sendMessage(tab.id, { action: 'TRIGGER_IMAGE_CROPPER' });
  } else if (info.menuItemId === 'researchie-save-page') {
    const targetUrl = info.linkUrl || tab.url || '';
    const title = tab.title || 'Saved Web Link';

    const payload = {
      type: 'link',
      title: title,
      content: {
        targetUrl: targetUrl,
        description: `Saved from ${new URL(targetUrl).hostname}`,
      },
      metadata: {
        sourceUrl: targetUrl,
        pageTitle: title,
        domainFavicon: `https://www.google.com/s2/favicons?domain=${new URL(targetUrl).hostname}&sz=64`,
      },
    };

    saveAtomToPlatform(payload);
  }
});

chrome.commands.onCommand.addListener(async (command, tab) => {
  if (!tab || !tab.id || tab.url?.startsWith('chrome://') || tab.url?.startsWith('edge://')) return;

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['projectMenu.js', 'content.js', 'blockPicker.js', 'cropper.js', 'qnaDrawer.js'],
    });
  } catch {}

  if (command === 'save-selection') {
    chrome.tabs.sendMessage(tab.id, { action: 'SAVE_SELECTION_TRIGGERED' });
  } else if (command === 'pick-block') {
    chrome.tabs.sendMessage(tab.id, { action: 'TRIGGER_BLOCK_PICKER' });
  } else if (command === 'select-image') {
    chrome.tabs.sendMessage(tab.id, { action: 'TRIGGER_IMAGE_SELECTOR' });
  } else if (command === 'crop-image') {
    chrome.tabs.sendMessage(tab.id, { action: 'TRIGGER_IMAGE_CROPPER' });
  } else if (command === 'open-sidebar') {
    chrome.tabs.sendMessage(tab.id, { action: 'TRIGGER_QNA_DRAWER' });
  }
});

// Connected means a token and the server it came from are saved (popup -> the link icon). Until then nothing
// is sent: a clip is held in the extension and the page shows a prompt to connect.
async function isConnected() {
  const { authToken, serverUrl } = await chrome.storage.local.get(['authToken', 'serverUrl']);
  return Boolean(authToken && serverUrl);
}
const NOT_CONNECTED = { success: false, code: 'NOT_CONNECTED', error: 'Not connected. Connect your account to use this.' };

async function saveAtomToPlatform(atomPayload) {
  // A fixed id before the first try means a retry of a save whose reply was lost is recognised by the
  // server as the same clip, not saved twice.
  if (!atomPayload.id) atomPayload.id = 'atom-' + crypto.randomUUID().replace(/-/g, '').slice(0, 16);
  if (!(await isConnected())) {
    // Held, not lost: it is sent by itself once the extension is connected. (A very large screenshot can
    // exceed what the browser lets an extension store; then it is not held, and the prompt says so.)
    try {
      await enqueueOffline(atomPayload, null);
      return { success: false, queued: true, needsConnect: true };
    } catch {
      return { success: false, queued: false, needsConnect: true, error: 'Not connected, and this clip is too large to hold. Connect and clip it again.' };
    }
  }
  try {
    const apiBase = await getWorkingApiBase();
    const storage = await chrome.storage.local.get(['activeProjectId', 'activeProjectTitle']);
    let projectId = atomPayload.projectId || storage.activeProjectId;

    if (!projectId) {
      try {
        const projRes = await fetch(`${apiBase}/projects`);
        if (projRes.ok) {
          const projJson = await projRes.json();
          if (projJson.data && projJson.data.length > 0) {
            projectId = projJson.data[0].id;
            await chrome.storage.local.set({
              activeProjectId: projJson.data[0].id,
              activeProjectTitle: projJson.data[0].title,
              activeProjectDesc: projJson.data[0].description || '',
              activeProjectColor: projJson.data[0].color_badge || projJson.data[0].color || '#325FEC',
            });
          }
        }
      } catch {}
    }

    if (!projectId) {
      projectId = 'proj-ai-main';
    }

    const completePayload = {
      ...atomPayload,
      projectId: projectId,
    };

    const res = await fetch(`${apiBase}/atoms`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(completePayload),
    });

    if (!res.ok) {
      const err = new Error(`Server status: ${res.status}`);
      err.status = res.status;
      throw err;
    }

    const data = await res.json();
    
    // Update last push time
    await chrome.storage.local.set({ lastPushTime: new Date().toISOString() });

    return { 
      success: true, 
      data: data.data,
      projectTitle: storage.activeProjectTitle || 'Active Project' 
    };
  } catch (error) {
    await enqueueOffline(atomPayload, error);
    // 401 = no token or a refused one: it will not sync until the extension is connected.
    return { success: false, queued: true, needsConnect: Boolean(error && error.status === 401) };
  }
}

// ==========================================================================
// OFFLINE QUEUE
// A save that fails (server down, no network, server error) is kept in chrome.storage.local.offlineQueue
// and sent again when the connection is back: on an alarm every minute while something is waiting, when
// the browser starts, when a page reports it is online, and from the Sync button. Only a response with
// ok status counts as saved. A 4xx answer means the server will never accept that clip as it is, so the
// clip stays in the queue marked `rejected` (nothing is thrown away) and only the Sync button retries it.
// ==========================================================================

const OFFLINE_ALARM = 'researchie-flush-offline';
let flushInFlight = null;
let queueLock = Promise.resolve();

// Read-modify-write of the queue runs one at a time, so a save and a flush cannot overwrite each other.
function withQueueLock(fn) {
  const run = queueLock.then(fn, fn);
  queueLock = run.catch(() => {});
  return run;
}

function isPermanentStatus(status) {
  return typeof status === 'number' && status >= 400 && status < 500 && status !== 408 && status !== 429;
}

async function readQueue() {
  const { offlineQueue } = await chrome.storage.local.get(['offlineQueue']);
  return Array.isArray(offlineQueue) ? offlineQueue : [];
}

async function enqueueOffline(atomPayload, error) {
  await withQueueLock(async () => {
    const storage = await chrome.storage.local.get(['activeProjectId']);
    const queue = await readQueue();
    const item = {
      ...atomPayload,
      // The project is fixed at the moment of the clip, so a later project switch cannot misfile it.
      projectId: atomPayload.projectId || storage.activeProjectId || undefined,
      queueId: crypto.randomUUID(),
      queuedAt: new Date().toISOString(),
    };
    if (isPermanentStatus(error && error.status)) {
      item.rejected = true;
      item.lastError = `HTTP ${error.status}`;
    }
    queue.push(item);
    await chrome.storage.local.set({ offlineQueue: queue, lastPushTime: new Date().toISOString() });
  });
  await syncOfflineAlarm();
}

// Keep the retry alarm on while something retryable is waiting, and off otherwise.
async function syncOfflineAlarm() {
  if (!chrome.alarms) return;
  const waiting = (await isConnected()) && (await readQueue()).some((item) => !item.rejected);
  const existing = await chrome.alarms.get(OFFLINE_ALARM);
  if (waiting && !existing) chrome.alarms.create(OFFLINE_ALARM, { delayInMinutes: 0.5, periodInMinutes: 1 });
  if (!waiting && existing) await chrome.alarms.clear(OFFLINE_ALARM);
}

// One flush at a time. includeRejected is for the Sync button: the user is asking to try everything again.
function flushOfflineQueue({ includeRejected = false } = {}) {
  if (!flushInFlight) {
    flushInFlight = doFlushOfflineQueue(includeRejected).finally(() => {
      flushInFlight = null;
    });
  }
  return flushInFlight;
}

async function doFlushOfflineQueue(includeRejected) {
  // Items queued by older versions have no id; give them one so they can be matched afterwards.
  const queue = await withQueueLock(async () => {
    const items = await readQueue();
    if (items.some((i) => !i.queueId)) {
      items.forEach((i) => {
        if (!i.queueId) i.queueId = crypto.randomUUID();
      });
      await chrome.storage.local.set({ offlineQueue: items });
    }
    return items;
  });

  // Nothing is sent while the extension is not connected; the clips stay in the queue.
  if (!(await isConnected())) return { synced: 0, remaining: queue.length, reachable: false, needsConnect: true };

  const todo = queue.filter((i) => includeRejected || !i.rejected);
  if (todo.length === 0) {
    await syncOfflineAlarm();
    return { synced: 0, remaining: queue.length, reachable: true };
  }

  const apiBase = await getWorkingApiBase();
  const { activeProjectId } = await chrome.storage.local.get(['activeProjectId']);
  const synced = new Set();
  const changes = new Map();
  let reachable = true;

  for (const item of todo) {
    const { queueId, queuedAt, rejected, lastError, ...payload } = item;
    if (!payload.projectId) payload.projectId = activeProjectId || 'proj-ai-main';
    try {
      const res = await fetch(`${apiBase}/atoms`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        synced.add(queueId);
      } else if (isPermanentStatus(res.status)) {
        changes.set(queueId, { rejected: true, lastError: `HTTP ${res.status}` });
      } else {
        // 5xx and other trouble: the server is unwell, so stop and try again later.
        changes.set(queueId, { lastError: `HTTP ${res.status}` });
        reachable = false;
        break;
      }
    } catch {
      reachable = false; // offline: stop at the first failure, the alarm tries again
      break;
    }
  }

  // Re-read the queue: clips saved while this flush ran must stay.
  const remaining = await withQueueLock(async () => {
    const latest = (await readQueue())
      .filter((i) => !synced.has(i.queueId))
      .map((i) => (changes.has(i.queueId) ? { ...i, ...changes.get(i.queueId) } : i));
    await chrome.storage.local.set({ offlineQueue: latest });
    return latest.length;
  });
  if (synced.size > 0) await chrome.storage.local.set({ lastPushTime: new Date().toISOString() });
  await syncOfflineAlarm();
  return { synced: synced.size, remaining, reachable };
}

if (chrome.alarms) {
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === OFFLINE_ALARM) flushOfflineQueue();
  });
}
chrome.runtime.onStartup.addListener(() => {
  flushOfflineQueue();
});
// Saving a token (popup -> Connect) sends the clips that were held while the extension was not connected.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.authToken && changes.authToken.newValue) {
    flushOfflineQueue().then(() => syncOfflineAlarm());
  }
});
// A service worker can wake on this event in some Chrome versions; the alarm covers the rest.
self.addEventListener('online', () => {
  flushOfflineQueue();
});
syncOfflineAlarm();

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'SAVE_ATOM') {
    saveAtomToPlatform(message.payload).then((res) => sendResponse(res));
    return true;
  }
  // A page asks for the popup so the person can paste a token. The popup opens on its Connect panel.
  if (message.action === 'OPEN_CONNECT') {
    (async () => {
      await chrome.storage.local.set({ connectPrompt: true });
      let opened = false;
      try {
        if (chrome.action && typeof chrome.action.openPopup === 'function') {
          await chrome.action.openPopup();
          opened = true;
        }
      } catch {
        // Chrome only opens a popup in some situations; the page then tells the person where to click.
      }
      sendResponse({ opened });
    })();
    return true;
  }
  if (message.action === 'FLUSH_OFFLINE_QUEUE') {
    flushOfflineQueue({ includeRejected: Boolean(message.includeRejected) })
      .then((result) => sendResponse({ success: true, ...result }))
      .catch((err) => sendResponse({ success: false, error: String((err && err.message) || err) }));
    return true;
  }
  if (message.action === 'DELETE_ATOM') {
    // Undo on the clip toast. The page scripts cannot reach the app themselves: they hard-coded
    // port 3000 and a web page's CORS rules apply to them. The background knows the real address.
    (async () => {
      try {
        const apiBase = await getWorkingApiBase();
        const res = await fetch(`${apiBase}/atoms?id=${encodeURIComponent(message.atomId)}`, { method: 'DELETE' });
        sendResponse({ success: res.ok });
      } catch (err) {
        sendResponse({ success: false, error: String((err && err.message) || err) });
      }
    })();
    return true;
  }
  // The in-page project menu lists every project so the user can change the destination without the popup.
  if (message.action === 'LIST_PROJECTS') {
    (async () => {
      if (!(await isConnected())) return sendResponse(NOT_CONNECTED);
      try {
        const apiBase = await getWorkingApiBase();
        const res = await fetch(`${apiBase}/projects`);
        if (!res.ok) {
          sendResponse({ success: false, error: `HTTP ${res.status}` });
          return;
        }
        const json = await res.json();
        sendResponse({ success: true, data: json.data || [] });
      } catch (err) {
        sendResponse({ success: false, error: String((err && err.message) || err) });
      }
    })();
    return true;
  }
  if (message.action === 'AI_SUMMARIZE') {
    (async () => {
      if (!(await isConnected())) return sendResponse(NOT_CONNECTED);
      try {
        const apiBase = await getWorkingApiBase();
        const res = await fetch(`${apiBase}/ai/summarize`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(message.payload || {}),
        });
        if (res.ok) {
          const json = await res.json();
          sendResponse(json);
        } else {
          const failure = await res.json().catch(() => null);
          sendResponse(failure && failure.error ? failure : { success: false, error: `HTTP ${res.status}` });
        }
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }
  if (message.action === 'AI_QNA') {
    (async () => {
      if (!(await isConnected())) return sendResponse(NOT_CONNECTED);
      try {
        const apiBase = await getWorkingApiBase();
        const res = await fetch(`${apiBase}/ai/qna`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(message.payload || {}),
        });
        if (res.ok) {
          const json = await res.json();
          sendResponse(json);
        } else {
          const failure = await res.json().catch(() => null);
          sendResponse(failure && failure.error ? failure : { success: false, error: `HTTP ${res.status}` });
        }
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }
  if (message.action === 'OPEN_SIDEPANEL_REQUEST') {
    if (chrome.sidePanel && typeof chrome.sidePanel.open === 'function') {
      const windowId = sender.tab?.windowId;
      const tabId = sender.tab?.id;
      if (windowId) {
        chrome.sidePanel.open({ windowId }).catch(() => {
          if (tabId) chrome.sidePanel.open({ tabId }).catch(() => {});
        });
      } else if (tabId) {
        chrome.sidePanel.open({ tabId }).catch(() => {});
      }
    }
    return true;
  }
  if (message.action === 'GET_WORKSPACE_STATE') {
    chrome.storage.local.get(
      ['activeProjectId', 'activeProjectTitle', 'activeProjectDesc', 'activeProjectColor', 'extensionEnabled', 'lastPushTime', 'apiBaseUrl'],
      (data) => sendResponse(data)
    );
    return true;
  }
  if (message.action === 'CAPTURE_SCREEN_AREA') {
    const windowId = sender.tab?.windowId || null;
    chrome.tabs.captureVisibleTab(windowId, { format: 'png' }, async (fullDataUrl) => {
      if (!fullDataUrl) {
        sendResponse({ success: false, error: 'Failed to capture tab' });
        return;
      }

      let finalImageUrl = fullDataUrl;
      const b = message.bounds;
      const dpr = b?.devicePixelRatio || 1;

      try {
        if (b && b.width > 10 && b.height > 10 && typeof OffscreenCanvas !== 'undefined') {
          const resBlob = await fetch(fullDataUrl).then((r) => r.blob());
          const imageBitmap = await createImageBitmap(resBlob);

          const cropX = Math.round(b.x * dpr);
          const cropY = Math.round(b.y * dpr);
          const cropW = Math.round(b.width * dpr);
          const cropH = Math.round(b.height * dpr);

          const offscreen = new OffscreenCanvas(cropW, cropH);
          const ctx = offscreen.getContext('2d');
          ctx.drawImage(imageBitmap, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);

          const croppedBlob = await offscreen.convertToBlob({ type: 'image/png' });
          const arrayBuffer = await croppedBlob.arrayBuffer();
          const bytes = new Uint8Array(arrayBuffer);
          let binary = '';
          const len = bytes.byteLength;
          for (let i = 0; i < len; i++) {
            binary += String.fromCharCode(bytes[i]);
          }
          finalImageUrl = `data:image/png;base64,${btoa(binary)}`;
        }
      } catch (err) {
        console.warn('Canvas cropping fallback:', err);
      }

      const userTag = message.tag ? message.tag.replace(/^#/, '').trim() : '';
      const customTitle = message.title?.trim() || (userTag ? `${userTag}` : `Screen Crop (${Math.round(b?.width || 0)}×${Math.round(b?.height || 0)}px)`);

      let hostname = 'localhost';
      try {
        if (sender.tab?.url) hostname = new URL(sender.tab.url).hostname;
      } catch {}

      const storage = await chrome.storage.local.get(['activeProjectId']);

      const payload = {
        projectId: message.projectId || storage.activeProjectId || 'proj-ai-main',
        type: 'image',
        title: customTitle,
        content: {
          imageUrl: finalImageUrl,
          description: `Captured ${Math.round(b?.width || 0)}×${Math.round(b?.height || 0)} region from ${sender.tab?.title || 'page'}`,
        },
        metadata: {
          sourceUrl: sender.tab?.url || '',
          pageTitle: sender.tab?.title || 'Web Source',
          domainFavicon: `https://www.google.com/s2/favicons?domain=${hostname}&sz=64`,
        },
        tags: message.tags || (userTag ? [userTag] : ['screenshot']),
      };

      saveAtomToPlatform(payload).then((res) => sendResponse(res));
    });
    return true;
  }
});
